#!/bin/sh
python BigramTester.py -f small_model.txt -t data/kafka.txt
