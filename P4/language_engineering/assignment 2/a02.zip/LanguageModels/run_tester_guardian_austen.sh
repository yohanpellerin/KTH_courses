#!/bin/sh
python BigramTester.py -f guardian_model.txt -t data/austen_test.txt
