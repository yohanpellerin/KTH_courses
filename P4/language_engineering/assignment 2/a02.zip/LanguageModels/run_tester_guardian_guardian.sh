#!/bin/sh
python BigramTester.py -f guardian_model.txt -t data/guardian_test.txt
